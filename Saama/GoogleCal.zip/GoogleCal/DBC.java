package com.saama.sgc.service.google;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBC {   

    private Connection _con;
    private ResultSet _rs;
    private Statement _statement;

    public synchronized ResultSet query(SQLObject obj) {
        if(obj==null) { throw new java.lang.NullPointerException("Error in DBC: query() - SQLObject is null."); }
        if(obj.getQuery()==null) { throw new java.lang.NullPointerException("Error in DBC: query() - getQuery() is empty."); }

        try {
        	//connection opened in the googlecal.java class
           // open();
            _rs = _statement.executeQuery(obj.getQuery());
            return _rs;
            /*obj.pre(_rs);
            while (_rs.next()) {
                obj.row(_rs);
            }
            obj.post();*/
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        	//connection closed in the googlecal.java class
            //close();
        	return _rs;
        }
    }

    public synchronized int update(String query) {
        System.out.println("Entered update method in dbc class");

        if(query==null || query.isEmpty()) { throw new java.lang.NullPointerException("Error in DBC: update() - query is empty."); }
        int result = -1;
        try {
        	//connection opened in the googlecal.java class
        	//open();
            result = _statement.executeUpdate(query);
            System.out.println("query executed");
            _con.commit();
            System.out.println("query commited");
            if (result == 0) { result = _statement.getUpdateCount(); }
        } catch (Exception e) {
            try { _con.rollback(); } catch (Exception r) { r.printStackTrace(); }
            e.printStackTrace();
        } finally {
        	//connection closed in the googlecal.java class
           // close();
        }

        return result;
    }


    public void open() throws SQLException, ClassNotFoundException {
    	System.out.println("entered open method of DBC class");
        Class.forName(GoogleConstant.JDBC_DRIVER);
         System.out.println("Connecting to a selected database...");
        _con = DriverManager.getConnection(GoogleConstant.DB_URL, GoogleConstant.USER, GoogleConstant.PASS);
         System.out.println("Connected database successfully...");
        _con.setAutoCommit(false);
        _statement = _con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

    }

    public void close() {
        try {
            if (_rs != null) {
                _rs.close();
            }
            if (_statement != null) {
                _statement.close();
            }
            if (_con != null) {
                _con.close();
            }
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
    }
    public static String fixTimestamp(java.sql.Timestamp timestamp) {
        if (timestamp != null) {
            return "'" + timestamp + "'";
        }
        return null;
    }

    public static String fixString(String str) {
        if (str != null) {
            return "'" + fixApostropheForSQLInsertion(str) + "'";
        }
        return null;
    }

    private static String fixApostropheForSQLInsertion(String str) {
        int index = str.indexOf('\'');
        String temp = str;
        if (index >= 0) {
            String before = str.substring(0, index+1) + "'";
            String after = str.substring(index + 1);
            temp = before + fixApostropheForSQLInsertion(after);
        }
        return temp;
    }

    public static Object fix(Object o) {
        if(o==null) {
            return null;
        } else if(o.getClass().equals(String.class)) {
            return fixString((String)o);
        } else if(o.getClass().equals(java.sql.Timestamp.class)) {
            return fixTimestamp((java.sql.Timestamp)o);
        } else {
            return o;
        }
    }

}
