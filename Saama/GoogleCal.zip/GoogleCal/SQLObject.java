package com.saama.sgc.service.google;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class SQLObject {
	private String _query;

	private SQLObject() {
	};

	public SQLObject(final String query) {
		this._query = query;
	}

	public String getQuery() {
		return this._query;
	}

	public void sp(final CallableStatement cs) throws SQLException {
	};

	public void pre(final ResultSet rs) throws SQLException {
	};

	public abstract void row(ResultSet rs) throws SQLException;

	public void post() {
	};
}
