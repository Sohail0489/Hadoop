package com.saama.sgc.service.google;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Timer {

	private final long _start;
	private final String _methodName;
	private static boolean _isShown = true;
	private static NumberFormat _numberFormat = new DecimalFormat("#0.00");

	private Timer() {
		this._methodName = Thread.currentThread().getStackTrace()[3].getMethodName();
		this._start = System.currentTimeMillis();
	}

	@Override
	public String toString() {
		return "Finished " + this._methodName + ": " + _numberFormat.format(this.getDuration()) + " (seconds)";
	}

	public float getDuration() {
		return this.stop() / 1000.0f;
	}

	public String getMethodName() {
		return this._methodName;
	}

	public void print() {
		if (_isShown) {
			System.out.println(this.toString());
		}
	}

	public static void disable() {
		_isShown = false;
	}

	public static void enable() {
		_isShown = true;
	}

	public static Timer start() {
		final Timer result = new Timer();
		if (_isShown) {
			System.out.println("Started " + result._methodName);
		}
		return result;
	}

	public long stop() {
		return System.currentTimeMillis() - this._start;
	}

	public static String trace(final StackTraceElement e[]) {
		String result = null;
		boolean doNext = false;
		for (final StackTraceElement s : e) {
			if (_isShown) {
				System.out.println(s.getMethodName());
			}
			if (doNext) {
				result = s.getMethodName();
				break;
			}
			doNext = s.getMethodName().equals("getStackTrace");
		}
		return result;
	}
}