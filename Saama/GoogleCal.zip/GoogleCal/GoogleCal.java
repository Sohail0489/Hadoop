package com.saama.sgc.service.google;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.StoredCredential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventAttendee;
import com.google.api.services.calendar.model.Events;
import com.saama.sgc.service.dao.UserDao;
import com.saama.sgc.service.model.User;

public class GoogleCal {
	/**
	 * Application name.
	 */
	private static final String APPLICATION_NAME = "Google Calendar";

	/**
	 * DBC connection to application.
	 */
	private static final DBC dbc = new DBC();

	/**
	 * Directory to store user credentials for this application.
	 */

	/**
	 * Global instance of the JSON factory.
	 */
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

	/**
	 * Global instance of the HTTP transport.
	 */
	private static HttpTransport HTTP_TRANSPORT;

	/**
	 * Global instance of the scopes required by this quickstart.
	 */
	private static final List<String> SCOPES = Arrays.asList(CalendarScopes.CALENDAR_READONLY,
			"https://www.googleapis.com/auth/userinfo.email");

	// Get current date
	private static final Date date = new Date();

	private static SimpleDateFormat dFormat = new SimpleDateFormat("MM/dd/yyyy");

	private static String ACCESS_TOKEN;

	// STARTING HARDCODED VARIABLES LINK THIS WITH FRONTEND PAGE N PROMPT FROM
	// USER

	private static String fromDate = "12/29/2015"; // max date from event table
	private static String toDate = "1/31/2016"; // dFormat.format(date); //
												// current day

	static {
		try {
			HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			// dbc.open();
		} catch (Throwable t) {
			t.printStackTrace();
			System.exit(1);
		}
	}

	private FileDataStoreFactory getDataStoreFactory(String emailId) throws IOException {
		File dataStoreDirectory = new File(System.getProperty("user.home"), ".credentials/" + emailId);
		FileDataStoreFactory dataStoreFactory = new FileDataStoreFactory(dataStoreDirectory);
		return dataStoreFactory;
	}

	// gets the end time stamp of an event
	private java.sql.Timestamp getEndTimestampFromItem(Event item) {

		java.sql.Timestamp result = null;

		if (item != null && item.getEnd() != null && item.getEnd().getDateTime() != null
				&& item.getEnd().getDateTime().getValue() > -1) {
			result = new java.sql.Timestamp(item.getEnd().getDateTime().getValue());
		}
		return result;
	}

	// gets the start time stamp of an event
	private java.sql.Timestamp getStartTimestampFromItem(Event item) {

		java.sql.Timestamp result = null;

		if (item != null && item.getStart() != null && item.getStart().getDateTime() != null
				&& item.getStart().getDateTime().getValue() > -1) {
			result = new java.sql.Timestamp(item.getStart().getDateTime().getValue());
		}
		return result;
	}

	/**
	 * Creates an authorized Credential object.
	 * 
	 * @param emailId
	 *
	 * @return an authorized Credential object.
	 * @throws IOException
	 */
	public Credential authorize(String emailId) throws IOException {
		FileDataStoreFactory dataStoreFactory = this.getDataStoreFactory(emailId);
		// Load client secrets.
		InputStream in = GoogleCalOld.class.getResourceAsStream("/conf/data/client_secret.json");
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		// Build flow and trigger user authorization request.
		
		 GoogleAuthorizationCodeFlow flow =
	                new GoogleAuthorizationCodeFlow.Builder(
	                        HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
	                        .setDataStoreFactory(dataStoreFactory)
	                        .setAccessType("offline")
	                        .build();
		Credential credential = new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");
		System.out.println("Credentials saved to " + dataStoreFactory.getDataDirectory());

		/*
		 * String new_path =
		 * DATA_STORE_FACTORY.getDataDirectory().toString().replaceAll("\\\\", "
		 * /"); System.out.println("Insert into users values(" + EMAIL_ID + ","
		 * + credential.getRefreshToken() + "," + "LOAD_FILE('" + new_path
		 * +"/StoredCredential')" +"," +"ACTIVE" + ")");
		 */

		/*
		 * dbc.update("Insert into users  values(" + DBC.fix(EMAIL_ID) + "," +
		 * DBC.fix(credential.getRefreshToken()) + "," +
		 * "LOAD_FILE('/tmp/sol.txt')" +"," +"'ACTIVE'" + ")");
		 */
		System.out.println("ACCESS_TOKEN =" + credential.getAccessToken() + "\n REFRESH TOKEN="
				+ credential.getRefreshToken() + "\n expiration in seconds " + credential.getExpiresInSeconds()
				+ "\n expiration in milliseconds " + credential.getExpirationTimeMilliseconds()
				+ "\nget data directory=" + dataStoreFactory.getDataDirectory());
		return credential;
	}

	/**
	 * Build and return an authorized Calendar client service.
	 * 
	 * @param emailId
	 *
	 * @return an authorized Calendar client service
	 * @throws IOException
	 */
	public Calendar getCalendarService(String emailId) throws IOException {
		Credential credential = this.authorize(emailId);
		return new com.google.api.services.calendar.Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential)
				.setApplicationName(APPLICATION_NAME).build();
	}

	/**
	 * Get the email id of the user
	 */
	public static void getEmail(String emailId) {
		try {
			StringBuilder result = new StringBuilder();
			URL url = new URL("https://www.googleapis.com/userinfo/email");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestProperty("Authorization", "Bearer " + ACCESS_TOKEN);
			conn.setRequestMethod("GET");
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			rd.close();
			emailId = result.toString();

			Pattern pattern = Pattern.compile("(\\b[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}\\b)");
			Matcher matcher = pattern.matcher(emailId);
			if (matcher.find()) {
				System.out.printf(matcher.group(1));
				emailId = matcher.group(1);
			}
		} catch (IOException ex) {
			// e.printStackTrace();
			Logger.getLogger(GoogleCal.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * getting the events of the user
	 * 
	 * @throws IOException
	 */

	public void getEvents(String email) throws IOException {
		Calendar service = this.getCalendarService(email);
		Events events;
		List<Event> items = new ArrayList<>();

		try {
			System.out.println("Getting events for " + email);
			events = service.events().list(email).setSingleEvents(true).setOrderBy("startTime")
					.setFields("items(summary,colorId,end,id,start,attendees),nextPageToken")
					.setTimeMin(new DateTime(dFormat.parse(fromDate))).setTimeMax(new DateTime(dFormat.parse(toDate)))
					// .setPageToken(pageToken)
					.execute();

			// Print out current date
			System.out.println("\nCurrent Date: " + dFormat.format(date));
			// System.out.println("");
			Timer t = Timer.start();

			items.addAll(events.getItems());
			List<Event> itemsFinal = new ArrayList<>();
			for (Event item : items) {

				// System.out.println("Inserting records into the table...");
				java.sql.Timestamp end = getEndTimestampFromItem(item);
				java.sql.Timestamp start = getStartTimestampFromItem(item);

				// Event Query
				dbc.update("Insert into Events_temp  values(" + DBC.fix(item.getId()) + "," + DBC.fix(item.getColorId())
						+ "," + DBC.fix(end) + "," + DBC.fix(start) + "," + DBC.fix(item.getSummary()) + ")");
				itemsFinal.add(item);

				if (item.getAttendees() != null) {
					List<EventAttendee> attendees = item.getAttendees();
					for (EventAttendee att : attendees) {

						itemsFinal.add(item);

						// Attendee Query
						// System.out.println("Inserting records into the
						// Attendees table...");
						dbc.update("Insert into attendees values(" + DBC.fix(item.getId()) + ","
								+ DBC.fix(att.getDisplayName()) + "," + DBC.fix(att.getEmail()) + ","
								+ DBC.fix(att.getResponseStatus()) + ")");
					}
				}
			}

			// Writing JSON Object to file
			// FileWriter file = new FileWriter("./test/items_new.json");
			/*
			 * try { // file.write(itemsFinal.toString()); System.out.println(
			 * "Successfully Copied JSON Object to File...");
			 * //System.out.println("\nJSON Object: " + itemsFinal);
			 * 
			 * } catch (IOException e) { e.printStackTrace();
			 * 
			 * } finally { // file.flush(); // file.close(); }
			 */

			t.print(); // this will print the duration in seconds

		} catch (ParseException | IOException ex) {
			Logger.getLogger(GoogleCal.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	// get all events method, it will get the distinct users from db and get
	// events for each
	public void getAllEvents() throws IOException {
		// 1 - TODO: make a query to user table and get all active users,
		// including event_refresh_date
		UserDao userDao = new UserDao();
		List<User> users = userDao.getAllActiveUsers();

		for (User user : users) {
			// 2- Call getEvents and pass emailId and start
			// date(event_refresh_date) and end dates (today timestamp)
			this.getEvents(user.getEmailId());
			// 3- TODO: Once the user data is retrieved, update its
			// event_refresh_date (today timestamp) in user table

		}
	}

	public static void main(String[] args) throws IOException {
		// Build a new authorized API client service.
		// Note: Do not confuse this class with the
		// com.google.api.services.calendar.model.Calendar class.
		GoogleCal cal = new GoogleCal();
		String emailId = "sohail.mohammed@saama.com";
		Calendar service = cal.getCalendarService(emailId);
		// get email ID for filtering
		// getEmail();

		// get events for a user
		// String email=EMAIL_ID;
		// System.out.println("entered email id is "+EMAIL_ID);
		// getEvents(EMAIL_ID);
		//cal.getAllEvents();

		// DATA_STORE_FACTORY.getDataDirectory()dbc.close();
	}

}
