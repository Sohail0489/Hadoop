package com.saama.sgc.service.google;

public class GoogleConstant {
	 /**
     * Application name.
     */
    public static final String APPLICATION_NAME = "Google Calendar";  
    
	 // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://10.20.202.52:3306/mydb";
    //static final String DB_URL = "jdbc:mysql://23.21.65.185:3306/mydb";
    //static final String DB_URL = "jdbc:mysql://23.21.65.185:3306/mydb_manish";

    //  Database credentials
    static final String USER = "calendaradmin";
    static final String PASS = "Saama@123";
    /*static final String USER = "root";
    static final String PASS = "Saama2015";*/  

}
