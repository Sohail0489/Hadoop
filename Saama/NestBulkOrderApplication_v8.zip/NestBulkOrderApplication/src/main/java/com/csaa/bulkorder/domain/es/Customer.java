/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csaa.bulkorder.domain.es;

import java.util.ArrayList;

/**
 *
 * @author gi45sha
 */
public class Customer {
    
    private String primary;
    private String firstName;
    private String middleName;
    private String lastName;
    private String preferredEmailAddress;
    private ArrayList<TelephoneNumber> telephoneNumber;
    private ArrayList<Address> address;
    
    public Customer() {
        
    }

	public String getPrimary() {
		return primary;
	}

	public void setPrimary(String primary) {
		this.primary = primary;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPreferredEmailAddress() {
		return preferredEmailAddress;
	}

	public void setPreferredEmailAddress(String preferredEmailAddress) {
		this.preferredEmailAddress = preferredEmailAddress;
	}

	public ArrayList<TelephoneNumber> getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(ArrayList<TelephoneNumber> telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public ArrayList<Address> getAddress() {
		return address;
	}

	public void setAddress(ArrayList<Address> address) {
		this.address = address;
	}
    
}
