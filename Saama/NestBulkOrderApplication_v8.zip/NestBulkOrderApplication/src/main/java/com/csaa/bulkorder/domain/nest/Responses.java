package com.csaa.bulkorder.domain.nest;

import java.util.ArrayList;

public class Responses {
	//private ArrayList<Response> reslist;
	private ArrayList<Response> batchNestResponse;
	private String batchStatus;// this is batch status
	private String batch_id;

	public String getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}

	public String getBatch_id() {
		return batch_id;
	}

	public void setBatch_id(String batch_id) {
		this.batch_id = batch_id;
	}

	public ArrayList<Response> getBatchNestResponse() {
		return batchNestResponse;
	}

	public void setBatchNestResponse(ArrayList<Response> batchNestResponse) {
		this.batchNestResponse = batchNestResponse;
	}
}
