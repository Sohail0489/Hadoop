package com.csaa.bulkorder.domain.pas;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MailingAddress {
    @SerializedName("cityName")
    @Expose
    private String cityName;
    @SerializedName("zipCode")
    @Expose
    private String zipCode;
    @SerializedName("streetAddressLine")
    @Expose
    private String streetAddressLine;
    @SerializedName("isoCountryCode")
    @Expose
    private String isoCountryCode;
    @SerializedName("isoRegionCode")
    @Expose
    private String isoRegionCode;
    @SerializedName("type")
    @Expose
    private String type;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MailingAddress() {
    }

    /**
     * 
     * @param isoRegionCode
     * @param streetAddressLine
     * @param zipCode
     * @param cityName
     * @param isoCountryCode
     * @param type
     */
    public MailingAddress(String cityName, String zipCode, String streetAddressLine, String isoCountryCode, String isoRegionCode, String type) {
        this.cityName = cityName;
        this.zipCode = zipCode;
        this.streetAddressLine = streetAddressLine;
        this.isoCountryCode = isoCountryCode;
        this.isoRegionCode = isoRegionCode;
        this.type = type;
    }

    /**
     * 
     * @return
     *     The cityName
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 
     * @param cityName
     *     The cityName
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    /**
     * 
     * @return
     *     The zipCode
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * 
     * @param zipCode
     *     The zipCode
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * 
     * @return
     *     The streetAddressLine
     */
    public String getStreetAddressLine() {
        return streetAddressLine;
    }

    /**
     * 
     * @param streetAddressLine
     *     The streetAddressLine
     */
    public void setStreetAddressLine(String streetAddressLine) {
        this.streetAddressLine = streetAddressLine;
    }

    /**
     * 
     * @return
     *     The isoCountryCode
     */
    public String getIsoCountryCode() {
        return isoCountryCode;
    }

    /**
     * 
     * @param isoCountryCode
     *     The isoCountryCode
     */
    public void setIsoCountryCode(String isoCountryCode) {
        this.isoCountryCode = isoCountryCode;
    }

    /**
     * 
     * @return
     *     The isoRegionCode
     */
    public String getIsoRegionCode() {
        return isoRegionCode;
    }

    /**
     * 
     * @param isoRegionCode
     *     The isoRegionCode
     */
    public void setIsoRegionCode(String isoRegionCode) {
        this.isoRegionCode = isoRegionCode;
    }

    /**
     * 
     * @return
     *     The type
     */
    public String getType() {
        return type;
    }

    /**
     * 
     * @param type
     *     The type
     */
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cityName).append(zipCode).append(streetAddressLine).append(isoCountryCode).append(isoRegionCode).append(type).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MailingAddress) == false) {
            return false;
        }
        MailingAddress rhs = ((MailingAddress) other);
        return new EqualsBuilder().append(cityName, rhs.cityName).append(zipCode, rhs.zipCode).append(streetAddressLine, rhs.streetAddressLine).append(isoCountryCode, rhs.isoCountryCode).append(isoRegionCode, rhs.isoRegionCode).append(type, rhs.type).isEquals();
    }
}
