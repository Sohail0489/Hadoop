package com.csaa.bulkorder.domain.nest;

//import org.codehaus.jackson.annotate.JsonIgnoreProperties;

//@JsonIgnoreProperties(ignoreUnknown = true)
public class Orders {
private String FIRST_NAME,LAST_NAME,ADDRESS1,ADDRESS2,CITY,STATE,POSTAL_CODE,COUNTRY,EMAIL,PHONE,LANGUAGE_PREFERENCE,
SKU;
private String ORDER_DATE;
String ORDER_NUMBER;
private int QUANTITY;
private boolean SIGNATURE_REQUIRED;

public Orders() {
	super();
}
public String getFIRST_NAME() {
	return FIRST_NAME;
}
public void setFIRST_NAME(String fIRST_NAME) {
	FIRST_NAME = fIRST_NAME;
}
public String getLAST_NAME() {
	return LAST_NAME;
}
public void setLAST_NAME(String lAST_NAME) {
	LAST_NAME = lAST_NAME;
}
public String getADDRESS1() {
	return ADDRESS1;
}
public void setADDRESS1(String aDDRESS1) {
	ADDRESS1 = aDDRESS1;
}
public String getADDRESS2() {
	return ADDRESS2;
}
public void setADDRESS2(String aDDRESS2) {
	ADDRESS2 = aDDRESS2;
}
public String getCITY() {
	return CITY;
}
public void setCITY(String cITY) {
	CITY = cITY;
}
public String getSTATE() {
	return STATE;
}
public void setSTATE(String sTATE) {
	STATE = sTATE;
}
public String getPOSTAL_CODE() {
	return POSTAL_CODE;
}
public void setPOSTAL_CODE(String pOSTAL_CODE) {
	POSTAL_CODE = pOSTAL_CODE;
}
public String getCOUNTRY() {
	return COUNTRY;
}
public void setCOUNTRY(String cOUNTRY) {
	COUNTRY = cOUNTRY;
}
public String getEMAIL() {
	return EMAIL;
}
public void setEMAIL(String eMAIL) {
	EMAIL = eMAIL;
}
public String getPHONE() {
	return PHONE;
}
public void setPHONE(String pHONE) {
	PHONE = pHONE;
}
public String getLANGUAGE_PREFERENCE() {
	return LANGUAGE_PREFERENCE;
}
public void setLANGUAGE_PREFERENCE(String lANGUAGE_PREFERENCE) {
	LANGUAGE_PREFERENCE = lANGUAGE_PREFERENCE;
}
public String getSKU() {
	return SKU;
}
public void setSKU(String sKU) {
	SKU = sKU;
}
public String getORDER_DATE() {
	return ORDER_DATE;
}
public void setORDER_DATE(String oRDER_DATE) {
	ORDER_DATE = oRDER_DATE;
}
public String getORDER_NUMBER() {
	return ORDER_NUMBER;
}
public void setORDER_NUMBER(String oRDER_NUMBER) {
	ORDER_NUMBER = oRDER_NUMBER;
}
public int getQUANTITY() {
	return QUANTITY;
}
public void setQUANTITY(int qUANTITY) {
	QUANTITY = qUANTITY;
}
public boolean isSIGNATURE_REQUIRED() {
	return SIGNATURE_REQUIRED;
}
public void setSIGNATURE_REQUIRED(boolean sIGNATURE_REQUIRED) {
	SIGNATURE_REQUIRED = sIGNATURE_REQUIRED;
}
}
