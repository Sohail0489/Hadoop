
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Generated("org.jsonschema2pojo")
public class HomeTelephoneNumber {

    @SerializedName("displayValue")
    @Expose
    private String displayValue;

    /**
     * No args constructor for use in serialization
     * 
     */
    public HomeTelephoneNumber() {
    }

    /**
     * 
     * @param displayValue
     */
    public HomeTelephoneNumber(String displayValue) {
        this.displayValue = displayValue;
    }

    /**
     * 
     * @return
     *     The displayValue
     */
    public String getDisplayValue() {
        return displayValue;
    }

    /**
     * 
     * @param displayValue
     *     The displayValue
     */
    public void setDisplayValue(String displayValue) {
        this.displayValue = displayValue;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(displayValue).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof HomeTelephoneNumber) == false) {
            return false;
        }
        HomeTelephoneNumber rhs = ((HomeTelephoneNumber) other);
        return new EqualsBuilder().append(displayValue, rhs.displayValue).isEquals();
    }

}
