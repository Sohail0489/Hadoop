
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Generated("org.jsonschema2pojo")
public class NamedInsuredSummary {

    @SerializedName("namedInsuredIdentifier")
    @Expose
    private String namedInsuredIdentifier;
    @SerializedName("primary")
    @Expose
    private String primary;
    @SerializedName("preferredEmailAddress")
    @Expose
    private String preferredEmailAddress;
    @SerializedName("dateOfBirth")
    @Expose
    private String dateOfBirth;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("maritalStatus")
    @Expose
    private String maritalStatus;
    @SerializedName("occupation")
    @Expose
    private String occupation;
    @SerializedName("homeTelephoneNumber")
    @Expose
    private HomeTelephoneNumber homeTelephoneNumber;
    @SerializedName("employee")
    @Expose
    private String employee;
    @SerializedName("name")
    @Expose
    private Name name;
    @SerializedName("preferredPostalAddress")
    @Expose
    private PreferredPostalAddress preferredPostalAddress;
    private MailingAddress mailingAddress;

    public MailingAddress getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(MailingAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	/**
     * No args constructor for use in serialization
     * 
     */
    public NamedInsuredSummary() {
    }

    /**
     * 
     * @param dateOfBirth
     * @param preferredEmailAddress
     * @param namedInsuredIdentifier
     * @param occupation
     * @param preferredPostalAddress
     * @param name
     * @param primary
     * @param gender
     * @param homeTelephoneNumber
     * @param employee
     * @param maritalStatus
     */
    public NamedInsuredSummary(String namedInsuredIdentifier, String primary, String preferredEmailAddress, String dateOfBirth, String gender, String maritalStatus, String occupation, HomeTelephoneNumber homeTelephoneNumber, String employee, Name name, PreferredPostalAddress preferredPostalAddress) {
        this.namedInsuredIdentifier = namedInsuredIdentifier;
        this.primary = primary;
        this.preferredEmailAddress = preferredEmailAddress;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.maritalStatus = maritalStatus;
        this.occupation = occupation;
        this.homeTelephoneNumber = homeTelephoneNumber;
        this.employee = employee;
        this.name = name;
        this.preferredPostalAddress = preferredPostalAddress;
    }

    /**
     * 
     * @return
     *     The namedInsuredIdentifier
     */
    public String getNamedInsuredIdentifier() {
        return namedInsuredIdentifier;
    }

    /**
     * 
     * @param namedInsuredIdentifier
     *     The namedInsuredIdentifier
     */
    public void setNamedInsuredIdentifier(String namedInsuredIdentifier) {
        this.namedInsuredIdentifier = namedInsuredIdentifier;
    }

    /**
     * 
     * @return
     *     The primary
     */
    public String getPrimary() {
        return primary;
    }

    /**
     * 
     * @param primary
     *     The primary
     */
    public void setPrimary(String primary) {
        this.primary = primary;
    }

    /**
     * 
     * @return
     *     The preferredEmailAddress
     */
    public String getPreferredEmailAddress() {
        return preferredEmailAddress;
    }

    /**
     * 
     * @param preferredEmailAddress
     *     The preferredEmailAddress
     */
    public void setPreferredEmailAddress(String preferredEmailAddress) {
        this.preferredEmailAddress = preferredEmailAddress;
    }

    /**
     * 
     * @return
     *     The dateOfBirth
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * 
     * @param dateOfBirth
     *     The dateOfBirth
     */
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * 
     * @return
     *     The gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * 
     * @param gender
     *     The gender
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * 
     * @return
     *     The maritalStatus
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * 
     * @param maritalStatus
     *     The maritalStatus
     */
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * 
     * @return
     *     The occupation
     */
    public String getOccupation() {
        return occupation;
    }

    /**
     * 
     * @param occupation
     *     The occupation
     */
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    /**
     * 
     * @return
     *     The homeTelephoneNumber
     */
    public HomeTelephoneNumber getHomeTelephoneNumber() {
        return homeTelephoneNumber;
    }

    /**
     * 
     * @param homeTelephoneNumber
     *     The homeTelephoneNumber
     */
    public void setHomeTelephoneNumber(HomeTelephoneNumber homeTelephoneNumber) {
        this.homeTelephoneNumber = homeTelephoneNumber;
    }

    /**
     * 
     * @return
     *     The employee
     */
    public String getEmployee() {
        return employee;
    }

    /**
     * 
     * @param employee
     *     The employee
     */
    public void setEmployee(String employee) {
        this.employee = employee;
    }

    /**
     * 
     * @return
     *     The name
     */
    public Name getName() {
        return name;
    }

    /**
     * 
     * @param name
     *     The name
     */
    public void setName(Name name) {
        this.name = name;
    }

    /**
     * 
     * @return
     *     The preferredPostalAddress
     */
    public PreferredPostalAddress getPreferredPostalAddress() {
        return preferredPostalAddress;
    }

    /**
     * 
     * @param preferredPostalAddress
     *     The preferredPostalAddress
     */
    public void setPreferredPostalAddress(PreferredPostalAddress preferredPostalAddress) {
        this.preferredPostalAddress = preferredPostalAddress;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(namedInsuredIdentifier).append(primary).append(preferredEmailAddress).append(dateOfBirth).append(gender).append(maritalStatus).append(occupation).append(homeTelephoneNumber).append(employee).append(name).append(preferredPostalAddress).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof NamedInsuredSummary) == false) {
            return false;
        }
        NamedInsuredSummary rhs = ((NamedInsuredSummary) other);
        return new EqualsBuilder().append(namedInsuredIdentifier, rhs.namedInsuredIdentifier).append(primary, rhs.primary).append(preferredEmailAddress, rhs.preferredEmailAddress).append(dateOfBirth, rhs.dateOfBirth).append(gender, rhs.gender).append(maritalStatus, rhs.maritalStatus).append(occupation, rhs.occupation).append(homeTelephoneNumber, rhs.homeTelephoneNumber).append(employee, rhs.employee).append(name, rhs.name).append(preferredPostalAddress, rhs.preferredPostalAddress).isEquals();
    }

}
