package com.csaa.bulkorder.domain.nest;

public class NestResponse {
	private String ORDER_NUMBER;
	private String STATUS;
	private String VALIDATION_ERRORS;
	
	public String getORDER_NUMBER() {
		return ORDER_NUMBER;
	}
	public void setORDER_NUMBER(String oRDER_NUMBER) {
		ORDER_NUMBER = oRDER_NUMBER;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getVALIDATION_ERRORS() {
		return VALIDATION_ERRORS;
	}
	public void setVALIDATION_ERRORS(String vALIDATION_ERRORS) {
		VALIDATION_ERRORS = vALIDATION_ERRORS;
	}
	
}
