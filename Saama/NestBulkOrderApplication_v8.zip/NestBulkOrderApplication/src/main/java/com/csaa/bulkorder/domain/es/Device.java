/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csaa.bulkorder.domain.es;

/**
 *
 * @author gi45sha
 */
public class Device {
    
    private String provider;
    private String manufacturer;
    private String deviceID;
    private String statusCode;
    private String creationDate;
    private String closureDate;
    private String expectedVoucherClosureDate;
    private String shipmentDate;
    private String shipmentTrackingNumber;
    private String shipmentCarrierCode;
    private String associationDate;
    private String activationDate;
    private String mobileTerminalReturnDate;
    private String orderID;
    private String orderStatus;
    
    public Device() {
        
    }

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getClosureDate() {
		return closureDate;
	}

	public void setClosureDate(String closureDate) {
		this.closureDate = closureDate;
	}

	public String getExpectedVoucherClosureDate() {
		return expectedVoucherClosureDate;
	}

	public void setExpectedVoucherClosureDate(String expectedVoucherClosureDate) {
		this.expectedVoucherClosureDate = expectedVoucherClosureDate;
	}

	public String getShipmentDate() {
		return shipmentDate;
	}

	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	public String getShipmentTrackingNumber() {
		return shipmentTrackingNumber;
	}

	public void setShipmentTrackingNumber(String shipmentTrackingNumber) {
		this.shipmentTrackingNumber = shipmentTrackingNumber;
	}

	public String getShipmentCarrierCode() {
		return shipmentCarrierCode;
	}

	public void setShipmentCarrierCode(String shipmentCarrierCode) {
		this.shipmentCarrierCode = shipmentCarrierCode;
	}

	public String getAssociationDate() {
		return associationDate;
	}

	public void setAssociationDate(String associationDate) {
		this.associationDate = associationDate;
	}

	public String getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}

	public String getMobileTerminalReturnDate() {
		return mobileTerminalReturnDate;
	}

	public void setMobileTerminalReturnDate(String mobileTerminalReturnDate) {
		this.mobileTerminalReturnDate = mobileTerminalReturnDate;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
    
}
