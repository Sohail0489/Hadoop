package com.csaa.bulkorder.loaddata;

import java.io.IOException;
import java.text.SimpleDateFormat;
import com.csaa.bulkorder.domain.es.Address;
import com.csaa.bulkorder.domain.es.Customer;
import com.csaa.bulkorder.domain.es.Device;
import com.csaa.bulkorder.domain.es.Dwelling;
import com.csaa.bulkorder.domain.es.PolicySummary;
import com.csaa.bulkorder.domain.es.TelephoneNumber;
import com.csaa.bulkorder.domain.nest.Orders;
import com.csaa.bulkorder.domain.pas.Address_;
import com.csaa.bulkorder.domain.pas.HomeTelephoneNumber;
import com.csaa.bulkorder.domain.pas.Insureds;
import com.csaa.bulkorder.domain.pas.MailingAddress;
import com.csaa.bulkorder.domain.pas.Name;
import com.csaa.bulkorder.domain.pas.NamedInsuredSummary;
import com.csaa.bulkorder.domain.pas.PreferredPostalAddress;
import com.csaa.bulkorder.domain.pas.PropertyPolicySummary;
import com.csaa.bulkorder.domain.pas.RetrievePolicyDetailResponse;
import com.csaa.bulkorder.property.GetPropertyValues;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Properties;


public class LoadData {
	Gson gson = new Gson();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
	String batchts = sdf.format(System.currentTimeMillis());

	/*
	 * getting nest attributes
	 */
	public Orders loadNest(RetrievePolicyDetailResponse rpdr) throws Exception {
		GetPropertyValues g = new GetPropertyValues();
		Properties properties = null;
		try {
			properties = g.getPropValues();
			// System.out.println(properties.getProperty("input_directory"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Orders ords = new Orders();
		PropertyPolicySummary pps = rpdr.getPropertyPolicySummary();
		Insureds ins = pps.getInsureds();
		ArrayList<NamedInsuredSummary> nislist = (ArrayList<NamedInsuredSummary>) ins.getNamedInsuredSummary();
		for (NamedInsuredSummary nis : nislist) {
			if (nis.getPrimary().equalsIgnoreCase("true")) {
				Name nam = nis.getName();
				PreferredPostalAddress ppa = nis.getPreferredPostalAddress();
				HomeTelephoneNumber htn = nis.getHomeTelephoneNumber();

				ords.setFIRST_NAME(nam.getFirstName());
				ords.setLAST_NAME(nam.getLastName());
				ords.setEMAIL(nis.getPreferredEmailAddress());
				ords.setADDRESS1(ppa.getStreetAddressLine());
				// ords.setADDRESS2(ppa.getAddress2());
				ords.setCITY(ppa.getCityName());
				ords.setSTATE(ppa.getIsoRegionCode());
				ords.setCOUNTRY(ppa.getIsoCountryCode());
				ords.setPOSTAL_CODE(ppa.getZipCode());
				ords.setPHONE(htn.getDisplayValue());
			}
		}
		// langPref en-us(eng usa), en-ca(eng canada), fr-ca(french canada) any
		// unrecognized will be set to a default en-us at nest
		ords.setLANGUAGE_PREFERENCE("en-us");
		// String orderts = sdf.format(System.currentTimeMillis());
		String orderId = "Order_" + pps.getPolicyNumber() + "_" + System.currentTimeMillis();
		ords.setORDER_NUMBER(orderId);
		ords.setORDER_DATE(sdf.format(System.currentTimeMillis()));
		ords.setSKU(properties.getProperty("device_name"));
		ords.setQUANTITY(1);
		/*
		 * This will be set true if shipment was returned or unable to be
		 * delivered ords.setSIGNATURE_REQUIRED(true);
		 */
		return ords;
	}

	/*
	 * assign attributes for es domain
	 */
	public PolicySummary loadPolicy(RetrievePolicyDetailResponse rpdr, String batchId, String orderId)
			throws Exception {
		PolicySummary polsum = new PolicySummary();
		Dwelling dwelling = new Dwelling();
		PropertyPolicySummary pps = rpdr.getPropertyPolicySummary();
		Insureds ins = pps.getInsureds();
		ArrayList<NamedInsuredSummary> nislist = (ArrayList<NamedInsuredSummary>) ins.getNamedInsuredSummary();
		com.csaa.bulkorder.domain.pas.Dwelling dwel = rpdr.getDwelling();
		ArrayList<Customer> custlist = new ArrayList<Customer>();
		ArrayList<Address> customerAddresseslist = new ArrayList<Address>();
		ArrayList<TelephoneNumber> customerPhoneNumberslist = new ArrayList<TelephoneNumber>();
		ArrayList<Device> devices = new ArrayList<Device>();

		polsum.setAgreementNumber(pps.getPolicyNumber());
		polsum.setProductCode(pps.getProductCode());
		polsum.setRiskState(pps.getRiskState());
		polsum.setStatus(pps.getStatus());
		polsum.setNestBatchID(batchId);
		polsum.setNestBatchStatus("initiated");

		for (NamedInsuredSummary nis : nislist) {
			Name nam = nis.getName();
			PreferredPostalAddress ppa = nis.getPreferredPostalAddress();
			MailingAddress ma = nis.getMailingAddress();
			HomeTelephoneNumber htn = nis.getHomeTelephoneNumber();
			Customer cus = new Customer();
			TelephoneNumber telno = new TelephoneNumber();

			cus.setFirstName(nam.getFirstName());
			cus.setLastName(nam.getLastName());
			// cus.setMiddleName(nam.getMiddleName());
			cus.setPreferredEmailAddress(nis.getPreferredEmailAddress());
			Address address = new Address();
			address.setStreetAddressLine(ppa.getStreetAddressLine());
			// address.setExtendedStreetAdressLine(ppa.getAddress2());
			address.setCityName(ppa.getCityName());
			address.setIsoRegionCode(ppa.getIsoRegionCode());
			address.setIsoCountryCode(ppa.getIsoCountryCode());
			address.setZipCode(ppa.getZipCode());
			address.setAddressType(ppa.getType());
			customerAddresseslist.add(address);
			Address address1 = new Address();
			address1.setStreetAddressLine(ma.getStreetAddressLine());
			address1.setCityName(ma.getCityName());
			address1.setIsoRegionCode(ma.getIsoRegionCode());
			address1.setIsoCountryCode(ma.getIsoCountryCode());
			address1.setZipCode(ma.getZipCode());
			address1.setAddressType(ma.getType());
			customerAddresseslist.add(address1);
			telno.setDisplayValue(htn.getDisplayValue());
			// telno.setPhoneType(htn.getPhoneType());

			customerPhoneNumberslist.add(telno);
			cus.setAddress(customerAddresseslist);
			cus.setTelephoneNumber(customerPhoneNumberslist);
			custlist.add(cus);
		}
		polsum.setNamedInsuredSummary(custlist);
		Address_ add_ = dwel.getAddress();
		dwelling.setStreetAddressLine(add_.getStreetAddressLine());
		dwelling.setCityName(add_.getCityName());
		dwelling.setIsoRegionCode(add_.getIsoRegionCode());
		dwelling.setIsoCountryCode(add_.getIsoCountryCode());
		dwelling.setZipCode(add_.getZipCode());
		Device d = new Device();
		d.setOrderID(orderId);
		d.setOrderStatus("processing");
		devices.add(d);
		dwelling.setDevices(devices);
		polsum.setDwelling(dwelling);
		return polsum;
	}
}
