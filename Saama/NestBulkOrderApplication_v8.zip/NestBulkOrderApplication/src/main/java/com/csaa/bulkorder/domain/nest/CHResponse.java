
package com.csaa.bulkorder.domain.nest;

public class CHResponse {
    
    String responseCode;
    String responseMessage;
    String policyNumber;
    String batchId;
    
    public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public CHResponse() {
    }
    
    public CHResponse(String responseCode, String responseMessage, String policyNumber)
    {
        this.responseCode = responseCode;
        this.responseMessage = responseMessage;
        this.policyNumber = policyNumber;
    }
    
    public String getResponseCode() {
        return responseCode;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    
}
