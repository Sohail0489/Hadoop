package com.csaa.bulkorder.domain.es;

import java.util.ArrayList;

public class PolicySummaries {
	private ArrayList<PolicySummary> batchOrders;

	public ArrayList<PolicySummary> getBatchOrders() {
		return batchOrders;
	}

	public void setBatchOrders(ArrayList<PolicySummary> batchOrders) {
		this.batchOrders = batchOrders;
	}
	
}
