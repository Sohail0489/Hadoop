/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csaa.bulkorder.domain.es;

import java.util.ArrayList;

/**
 *
 * @author Sohail.Mohammed
 */
public class Dwelling {
    
	private String enrollmentStatus;
	private String cityName;
	private String zipCode;
	private String streetAddressLine;
	private String isoCountryCode;
	private String isoRegionCode;
	private ArrayList<Device> devices = new ArrayList<Device>();
	public String getEnrollmentStatus() {
		return enrollmentStatus;
	}
	public void setEnrollmentStatus(String enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getStreetAddressLine() {
		return streetAddressLine;
	}
	public void setStreetAddressLine(String streetAddressLine) {
		this.streetAddressLine = streetAddressLine;
	}
	public String getIsoCountryCode() {
		return isoCountryCode;
	}
	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}
	public String getIsoRegionCode() {
		return isoRegionCode;
	}
	public void setIsoRegionCode(String isoRegionCode) {
		this.isoRegionCode = isoRegionCode;
	}
	public ArrayList<Device> getDevices() {
		return devices;
	}
	public void setDevices(ArrayList<Device> devices) {
		this.devices = devices;
	}
    
    
    
}
