package com.csaa.bulkorder.job;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Properties;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.csaa.bulkorder.connector.RestClient;
import com.csaa.bulkorder.domain.nest.CHBatchResponse;
import com.csaa.bulkorder.domain.nest.CHResponse;
import com.csaa.bulkorder.domain.nest.Response;
import com.csaa.bulkorder.domain.nest.Responses;
import com.csaa.bulkorder.property.GetPropertyValues;
import com.google.gson.Gson;

public class JobB extends QuartzJobBean {
	Gson gson = new Gson();
	GetPropertyValues g = new GetPropertyValues();
	Properties properties = null;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

	// @Override
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		final Object Object = null;
		GetPropertyValues g = new GetPropertyValues();

		try {
			properties = g.getPropValues();
			// System.out.println(properties.getProperty("Input_Directory"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// call to connedted homes ES to get initiated batch ids, get comma
		// seperated batch ids as string
		HashMap<String, String> createdBatchId = outboundCalls(properties.getProperty("connectedhomes_getbatches"),
				"get", Object, "basic");
		if (Integer.parseInt(createdBatchId.get("status")) == 200) {
			CHBatchResponse chBatchResponse = gson.fromJson(createdBatchId.get("body"), CHBatchResponse.class);
			for (CHResponse chresp : chBatchResponse.getPolicyResponses()) {
				HashMap<String, String> batchResponse = outboundCalls(
						"/v1/bulk/" + properties.getProperty("partner_name") + "/batches.json?batch_id="
								+ chresp.getBatchId() + "&status=BATCH_VALIDATED",
						"get", Object, "digest");
				// if the header response is not 200 then i can parse the
				// response body to get the error
				String errorDescription = batchResponse.get("body").split(",")[1].split(":")[1];//// if
																								//// above
																								//// request
																								//// failed
																								//// then
																								//// grabbing
																								//// the
																								//// error
																								//// details
				if (Integer.parseInt(batchResponse.get("status")) == 200) {
					int statusIndex = batchResponse.get("body").lastIndexOf("status") + 10;
					String statusValue = batchResponse.get("body").substring(statusIndex).split("\"")[0];

					if (statusValue == "BATCH_VALIDATED" || statusValue == "BATCH_INVALID"
							|| statusValue == "BATCH_COMPLETED") {
						HashMap<String, String> orderInvalidResponse = outboundCalls(
								"/v1/bulk/" + properties.getProperty("partner_name")
										+ "/orders.json?status=<PROCESSING|COMPLETED|VALIDATION_ERROR|FAILED>&batch_id="
										+ chresp.getBatchId()
										+ "&fields=batch_id,order_number,status,tracking_number,carrier",
								"get", Object, "digest");
						errorDescription = orderInvalidResponse.get("body").split(",")[1].split(":")[1];// if
																										// above
																										// request
																										// failed
																										// then
																										// grabbing
																										// the
																										// error
																										// details
						if (Integer.parseInt(orderInvalidResponse.get("status")) == 200) {
							// how to send to csaa rep(file with policy no.s and
							// status/comment)
							Responses res = gson.fromJson(orderInvalidResponse.get("body"), Responses.class);
							HashMap<String, String> esResponse = outboundCalls(
									properties.getProperty("connedhomes_orderupdate"), "post", Responses.class,
									"basic");
							if (Integer.parseInt(esResponse.get("status")) == 200) {
								if (statusValue == "BATCH_INVALID") {
									try {
										FileWriter fstream = new FileWriter(properties.getProperty("orders_failed")
												+ "/orders_failed_" + sdf.format(System.currentTimeMillis()) + ".txt");
										BufferedWriter out = new BufferedWriter(fstream);
										out.write("Policy Number");
										for (Response resp : res.getBatchNestResponse()) {
											out.write(resp.getOrder_number().split("_")[1]);
										}
										out.close();
									} catch (Exception e) {// Catch exception if
															// any
										System.err.println("Error: " + e.getMessage());
									}

								}
								if (statusValue == "BATCH_COMPLETED") {
									try {
										FileWriter fstream = new FileWriter(properties.getProperty("orders_processed")
												+ "/orders_failed_" + sdf.format(System.currentTimeMillis()) + ".txt");
										BufferedWriter out = new BufferedWriter(fstream);
										out.write("Policy Number\tCarrier\tTracking Number");
										for (Response resp : res.getBatchNestResponse()) {
											out.write(resp.getOrder_number().split("_")[1] + "\t" + resp.getCarrier()
													+ "\t" + resp.getTracking_number());
										}
										out.close();
									} catch (Exception e) {// Catch exception if
															// any
										System.err.println("Error: " + e.getMessage());
									}
								}
							}
						}
					}
				} else {
					System.out.println("Failed for " + errorDescription.substring(0, errorDescription.length() - 2));
					System.exit(1);
				}
			}
		} else {
			System.out.println("Connected Homes server is down");
			System.exit(1);
		}
	}

	public HashMap<String, String> outboundCalls(String uri, String method, Object obj, String type) {
		int nestStatusValue = 404, j = 0;
		HashMap<String, String> responseUri = new HashMap<>();
		while (nestStatusValue == 404 && j < 5) {
			try {
				if (type.equalsIgnoreCase("digest")) {
					responseUri = new RestClient().digestCall(uri, method, obj);
				} else {
					if (method == "post") {
						responseUri = new RestClient().post(uri, gson.toJson(obj));
					} else {
						responseUri = new RestClient().get(uri);
					}
				}
				nestStatusValue = Integer.parseInt(responseUri.get("status"));
				j++;
				Thread.sleep(60000); // 1000 milliseconds is one second.
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return responseUri;
	}
}