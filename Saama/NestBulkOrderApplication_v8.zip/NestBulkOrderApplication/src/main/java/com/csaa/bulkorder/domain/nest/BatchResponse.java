package com.csaa.bulkorder.domain.nest;

public class BatchResponse {
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
