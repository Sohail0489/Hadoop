
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class PropertyPolicySummary {

    private String productCode;
    private String policyNumber;
    private String riskState;
    private String status;
    private Insureds insureds;

    public PropertyPolicySummary() {
    }

   
    /*public PropertyPolicySummary(String policyIdentifier, String lineOfBusiness, String productCode, String policyPrefix, String policyNumber, String riskState, String type, String termEffectiveDate, String termExpirationDate, String termAmount, String status, String writingCompany, String inceptionDate, String dataSource, String quoteId, String customerNumber, Insureds insureds, String countryCode, String baseDate, String policyDueDate, String currentRevision, String versionNumber, String revisionNumber, String pendingRevisionNumber, String referencedMembership, String statusDate) {
       
        this.productCode = productCode;
        this.policyNumber = policyNumber;
        this.riskState = riskState;
        this.status = status;
        this.insureds = insureds;
       
    }*/

  
    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

 
    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getRiskState() {
        return riskState;
    }


    public void setRiskState(String riskState) {
        this.riskState = riskState;
    }

   
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Insureds getInsureds() {
        return insureds;
    }

    public void setInsureds(Insureds insureds) {
        this.insureds = insureds;
    }
   

}
