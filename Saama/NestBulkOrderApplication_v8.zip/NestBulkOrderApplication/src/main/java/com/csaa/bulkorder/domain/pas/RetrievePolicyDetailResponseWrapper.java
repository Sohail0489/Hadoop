package com.csaa.bulkorder.domain.pas;

public class RetrievePolicyDetailResponseWrapper {
	private RetrievePolicyDetailResponse retrievePolicyDetailResponse;

	public RetrievePolicyDetailResponse getRetrievePolicyDetailResponse() {
		return retrievePolicyDetailResponse;
	}

	public void setRetrievePolicyDetailResponse(RetrievePolicyDetailResponse retrievePolicyDetailResponse) {
		this.retrievePolicyDetailResponse = retrievePolicyDetailResponse;
	}
	
}
