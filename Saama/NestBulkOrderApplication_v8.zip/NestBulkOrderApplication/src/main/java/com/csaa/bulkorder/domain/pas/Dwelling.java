
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class Dwelling {
    private Address_ address;

	public Dwelling() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address_ getAddress() {
		return address;
	}

	public void setAddress(Address_ address) {
		this.address = address;
	}
  
  
}
