/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csaa.bulkorder.domain.es;

/**
 *
 * @author gi45sha
 */
public class Address {
    
    private String cityName;
    private String zipCode;
    private String streetAddressLine;
    private String extendedStreetAdressLine;
    private String isoCountryCode;
    private String isoRegionCode;
    private String addressType;
    
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getStreetAddressLine() {
		return streetAddressLine;
	}
	public void setStreetAddressLine(String streetAddressLine) {
		this.streetAddressLine = streetAddressLine;
	}
	public String getExtendedStreetAdressLine() {
		return extendedStreetAdressLine;
	}
	public void setExtendedStreetAdressLine(String extendedStreetAdressLine) {
		this.extendedStreetAdressLine = extendedStreetAdressLine;
	}
	public String getIsoCountryCode() {
		return isoCountryCode;
	}
	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}
	public String getIsoRegionCode() {
		return isoRegionCode;
	}
	public void setIsoRegionCode(String isoRegionCode) {
		this.isoRegionCode = isoRegionCode;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
  
    
}
