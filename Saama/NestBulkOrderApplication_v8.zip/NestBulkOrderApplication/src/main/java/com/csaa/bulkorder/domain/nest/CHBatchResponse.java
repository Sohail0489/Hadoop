package com.csaa.bulkorder.domain.nest;

import java.util.ArrayList;

/**
 *
 * @author gi45sha
 */
public class CHBatchResponse {
    
    ArrayList<CHResponse> policyResponses;

	public ArrayList<CHResponse> getPolicyResponses() {
		return policyResponses;
	}

	public void setPolicyResponses(ArrayList<CHResponse> policyResponses) {
		this.policyResponses = policyResponses;
	}
}
