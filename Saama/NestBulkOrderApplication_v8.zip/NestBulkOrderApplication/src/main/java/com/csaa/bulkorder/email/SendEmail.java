package com.csaa.bulkorder.email;

import java.io.IOException;
import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;
import com.csaa.bulkorder.property.GetPropertyValues;  
public class SendEmail  
{  

public void composeEmail(String sub, HashMap<String, String> failedPolicies) {
	// TODO Auto-generated method stub
	GetPropertyValues g = new GetPropertyValues();
	Properties prop = null;
	String from = prop.getProperty("from_email");//change accordingly  
	String to = prop.getProperty("to_email");//change accordingly  
	String host = "localhost";//or IP address  
	//Get the session object  
	Properties properties = System.getProperties();  
	properties.setProperty("mail.smtp.host", host);  
	Session session = Session.getDefaultInstance(properties); 
	try{  
		prop = g.getPropValues();
        MimeMessage message = new MimeMessage(session);  
        message.setFrom(new InternetAddress(from));  
        message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
        message.setSubject(sub);  
        //message.setText();
        // message.setText("Hello, this is example of sending email");  
        // Send message  
        Transport.send(message);  
        System.out.println("message sent successfully....");  
 
     }catch (MessagingException mex) {mex.printStackTrace();
     }catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
     }  

	}
} 
