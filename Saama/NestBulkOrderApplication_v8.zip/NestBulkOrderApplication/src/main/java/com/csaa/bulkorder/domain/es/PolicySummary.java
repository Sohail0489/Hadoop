/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csaa.bulkorder.domain.es;

import java.util.ArrayList;

/**
 *
 * @author gi45sha
 */
public class PolicySummary {
    
    private String agreementNumber;
    private String productCode;
    private String riskState;
    private String status;
    private String nestBatchID;
    private String nestBatchStatus;
    private ArrayList<Customer> namedInsuredSummary;
    private Dwelling dwelling;
    
    public String getNestBatchID() {
		return nestBatchID;
	}

	public void setNestBatchID(String nestBatchID) {
		this.nestBatchID = nestBatchID;
	}

	public String getNestBatchStatus() {
		return nestBatchStatus;
	}

	public void setNestBatchStatus(String nestBatchStatus) {
		this.nestBatchStatus = nestBatchStatus;
	}

	public PolicySummary(){
    }

	public String getAgreementNumber() {
		return agreementNumber;
	}

	public void setAgreementNumber(String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRiskState() {
		return riskState;
	}

	public void setRiskState(String riskState) {
		this.riskState = riskState;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ArrayList<Customer> getNamedInsuredSummary() {
		return namedInsuredSummary;
	}

	public void setNamedInsuredSummary(ArrayList<Customer> namedInsuredSummary) {
		this.namedInsuredSummary = namedInsuredSummary;
	}

	public Dwelling getDwelling() {
		return dwelling;
	}

	public void setDwelling(Dwelling dwelling) {
		this.dwelling = dwelling;
	}
}
