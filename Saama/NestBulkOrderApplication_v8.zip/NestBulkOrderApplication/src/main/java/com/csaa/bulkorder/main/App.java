package com.csaa.bulkorder.main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import com.csaa.bulkorder.property.ClassPathHacker;
import com.csaa.bulkorder.property.GetPropertyValues;

public class App {

	private static void updateQuartzCronExpression(String JobA_Time, String JobB_Time, File dir)
			throws TransformerFactoryConfigurationError, SAXException, IOException, ParserConfigurationException,
			XPathExpressionException, TransformerException {
		InputStream is = App.class.getClassLoader().getResourceAsStream("Spring-Quartz.xml");
		// 1- Build the doc from the XML file
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
		// 2- Locate the node(s) with xpath
		XPath xpath = XPathFactory.newInstance().newXPath();
		NodeList nodes_a = (NodeList) xpath.evaluate("//*[contains(@value, 'JobA_Time')]", doc, XPathConstants.NODESET);
		NodeList nodes_b = (NodeList) xpath.evaluate("//*[contains(@value, 'JobB_Time')]", doc, XPathConstants.NODESET);
		// 3- Make the change on the selected nodes
		for (int idx = 0; idx < nodes_a.getLength(); idx++) {
			Node value = nodes_a.item(idx).getAttributes().getNamedItem("value");
			String val = value.getNodeValue();
			value.setNodeValue(val.replaceAll("JobA_Time", JobA_Time));
		}
		for (int idx = 0; idx < nodes_b.getLength(); idx++) {
			Node value = nodes_b.item(idx).getAttributes().getNamedItem("value");
			String val = value.getNodeValue();
			value.setNodeValue(val.replaceAll("JobB_Time", JobB_Time));
		}
		// 4- Save the result to a new XML doc

		Transformer xformer = TransformerFactory.newInstance().newTransformer();
		xformer.transform(new DOMSource(doc), new StreamResult(new File(dir+"/Quartz_temp.xml")));
	}

	private static void deleteFile(File dir) {
		try {
			System.out.println("Deleting Quartz_temp.xml from local ");
			dir.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws Exception {
		File dir=new File("./temp_quarty_xml");
		if (!dir.exists()) {
			dir.mkdirs();
		}
		GetPropertyValues g = new GetPropertyValues();
        Properties properties = null;
       // final Class[] parameters = new Class[]{URL.class};
        try {
        	properties = g.getPropValues();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
		updateQuartzCronExpression(properties.getProperty("JobA_Time"),properties.getProperty("JobB_Time"),dir);
		System.out.println("calling classpathxmlapplicationcontext file is ");
		new ClassPathHacker().addFile(dir);
		System.out.println("deleting quartz temp xml file");
		deleteFile(dir);
		InputStream in =(InputStream)App.class.getClassLoader().getResourceAsStream("Quartz_temp.xml");
		if(in!=null){
			System.out.println("temp quartz_temp.xml file added to class path");
		}
		new ClassPathXmlApplicationContext("/Quartz_temp.xml");
	}
}