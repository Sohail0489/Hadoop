package com.csaa.bulkorder.domain.nest;

import java.util.ArrayList;

public class Order {
	private ArrayList<Orders> orders;

	public ArrayList<Orders> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<Orders> orders) {
		this.orders = orders;
	}
}
