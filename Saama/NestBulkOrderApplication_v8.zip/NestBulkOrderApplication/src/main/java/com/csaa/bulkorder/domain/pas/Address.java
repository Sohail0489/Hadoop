
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Generated("org.jsonschema2pojo")
public class Address {

    @SerializedName("cityName")
    @Expose
    private String cityName;
    @SerializedName("zipCode")
    @Expose
    private String zipCode;
    @SerializedName("streetAddressLine")
    @Expose
    private String streetAddressLine;
    @SerializedName("isoCountryCode")
    @Expose
    private String isoCountryCode;
    @SerializedName("isoRegionCode")
    @Expose
    private String isoRegionCode;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Address() {
    }

    /**
     * 
     * @param isoRegionCode
     * @param streetAddressLine
     * @param zipCode
     * @param cityName
     * @param isoCountryCode
     */
    public Address(String cityName, String zipCode, String streetAddressLine, String isoCountryCode, String isoRegionCode) {
        this.cityName = cityName;
        this.zipCode = zipCode;
        this.streetAddressLine = streetAddressLine;
        this.isoCountryCode = isoCountryCode;
        this.isoRegionCode = isoRegionCode;
    }

    /**
     * 
     * @return
     *     The cityName
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 
     * @param cityName
     *     The cityName
     */
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    /**
     * 
     * @return
     *     The zipCode
     */
    public String getZipCode() {
        return zipCode;
    }

    /**
     * 
     * @param zipCode
     *     The zipCode
     */
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * 
     * @return
     *     The streetAddressLine
     */
    public String getStreetAddressLine() {
        return streetAddressLine;
    }

    /**
     * 
     * @param streetAddressLine
     *     The streetAddressLine
     */
    public void setStreetAddressLine(String streetAddressLine) {
        this.streetAddressLine = streetAddressLine;
    }

    /**
     * 
     * @return
     *     The isoCountryCode
     */
    public String getIsoCountryCode() {
        return isoCountryCode;
    }

    /**
     * 
     * @param isoCountryCode
     *     The isoCountryCode
     */
    public void setIsoCountryCode(String isoCountryCode) {
        this.isoCountryCode = isoCountryCode;
    }

    /**
     * 
     * @return
     *     The isoRegionCode
     */
    public String getIsoRegionCode() {
        return isoRegionCode;
    }

    /**
     * 
     * @param isoRegionCode
     *     The isoRegionCode
     */
    public void setIsoRegionCode(String isoRegionCode) {
        this.isoRegionCode = isoRegionCode;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cityName).append(zipCode).append(streetAddressLine).append(isoCountryCode).append(isoRegionCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Address) == false) {
            return false;
        }
        Address rhs = ((Address) other);
        return new EqualsBuilder().append(cityName, rhs.cityName).append(zipCode, rhs.zipCode).append(streetAddressLine, rhs.streetAddressLine).append(isoCountryCode, rhs.isoCountryCode).append(isoRegionCode, rhs.isoRegionCode).isEquals();
    }

}
