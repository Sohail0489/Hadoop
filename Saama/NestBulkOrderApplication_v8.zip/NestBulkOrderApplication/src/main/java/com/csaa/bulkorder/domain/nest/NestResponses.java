package com.csaa.bulkorder.domain.nest;

import java.util.ArrayList;

public class NestResponses {
	private ArrayList<NestResponse> nestResponses;
	private BatchResponse bathresponse;
	
	
	public ArrayList<NestResponse> getNestResponses() {
		return nestResponses;
	}
	public void setNestResponses(ArrayList<NestResponse> nestResponses) {
		this.nestResponses = nestResponses;
	}
	public BatchResponse getBathresponse() {
		return bathresponse;
	}
	public void setBathresponse(BatchResponse bathresponse) {
		this.bathresponse = bathresponse;
	}
	
}
