package com.csaa.bulkorder.job;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Properties;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import com.csaa.bulkorder.connector.RestClient;
import com.csaa.bulkorder.domain.es.PolicySummaries;
import com.csaa.bulkorder.domain.es.PolicySummary;
import com.csaa.bulkorder.domain.nest.CHBatchResponse;
import com.csaa.bulkorder.domain.nest.CHResponse;
import com.csaa.bulkorder.domain.nest.NestResponse;
import com.csaa.bulkorder.domain.nest.NestResponses;
import com.csaa.bulkorder.domain.nest.Order;
import com.csaa.bulkorder.domain.nest.Orders;
import com.csaa.bulkorder.domain.nest.Response;
import com.csaa.bulkorder.domain.nest.Responses;
import com.csaa.bulkorder.domain.pas.RetrievePolicyDetailResponseWrapper;
import com.csaa.bulkorder.email.SendEmail;
import com.csaa.bulkorder.loaddata.LoadData;
import com.csaa.bulkorder.property.GetPropertyValues;
import com.google.gson.Gson;
import java.util.HashMap;
import java.util.Iterator;

public class JobA extends QuartzJobBean {
	Gson gson = new Gson();
	LoadData ld = new LoadData();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
	String ts = sdf.format(System.currentTimeMillis());
	String batchId = "Batch_csaa" + sdf.format(System.currentTimeMillis());
	Order ord = new Order();
	ArrayList<Orders> orderslist = new ArrayList<Orders>();
	PolicySummaries polsums = new PolicySummaries();
	ArrayList<PolicySummary> polsumlist = new ArrayList<PolicySummary>();
	ArrayList<String> filesprocessed = new ArrayList<String>();
	HashMap<String,String> failedPolicies = new HashMap<String,String>();
	Responses resps = new Responses();
	ArrayList<Response> resplist = new ArrayList<Response>();
	final Object Object = null;

	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		ArrayList<String> policyno = new ArrayList<String>();
		GetPropertyValues g = new GetPropertyValues();
		Properties properties = null;
		try {
			properties = g.getPropValues();
			System.out.println(properties.getProperty("input_directory"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String inputCSVFile = properties.getProperty("input_directory");
		File policyFilesDirectory = new File(inputCSVFile);
		if (!policyFilesDirectory.isDirectory()) {
			System.out.println(properties.getProperty("input_directory") + " is not a directory");
			System.exit(1);
		}

		if (policyFilesDirectory.list().length < 1) {
			System.out.println("No files from CSAA REP TODAY @ " + properties.getProperty("input_directory"));
			System.exit(0);
		}
		for (File file : policyFilesDirectory.listFiles()) {
			File order_placed = new File(file.getParent() + "\\order_placed\\");
			if (!order_placed.exists()) {
				order_placed.mkdirs();
				System.out.println("directory not exists, creating one");
			}
			if (!file.isDirectory()) {
				BufferedReader br = null;
				String line = "";
				try {
					filesprocessed.add(file.getName());
					br = new BufferedReader(new FileReader(file));
					System.out.println(">>> Reading file : " + file);
					while ((line = br.readLine()) != null) {
						policyno.add(line);
					}
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		for (String policyNo : policyno) {
			try {
				System.out.println("processing for policy no.=" + policyNo);
				System.out.println("line read is -->>" + policyNo.toString());
				// Pas api call
				String url = properties.getProperty("pass") + policyNo;
				HashMap<String, String> pasResponse = outboundCalls(url, "get", Object, "basic");
				if (Integer.parseInt(pasResponse.get("status")) == 200) {
					// System.out.println("JSON Response " +
					// pasResponse.split("@")[1]);
					RetrievePolicyDetailResponseWrapper rpdr = gson.fromJson(pasResponse.get("body"),
							RetrievePolicyDetailResponseWrapper.class);
					// System.out.println("RetrievePolicyDetailResponse class is
					// " + rpdr);
					Orders ords = null;
					ords = ld.loadNest(rpdr.getRetrievePolicyDetailResponse());
					// System.out.println(">>> Orders : " + gson.toJson(ords));
					orderslist.add(ords);
					// System.out.println("order of the policyno is " + ords +
					// "\n the order no passed to policy is" +
					// ords.getORDER_NUMBER());
					PolicySummary polsum = null;
					polsum = ld.loadPolicy(rpdr.getRetrievePolicyDetailResponse(), batchId, ords.getORDER_NUMBER());
					polsumlist.add(polsum);
					// System.out.println(">>> PolicySummary :
					// "+gson.toJson(polsum));
				} else if (Integer.parseInt(pasResponse.get("status")) == 404) {
					System.out.println("Incorrect Policy no. "+policyNo);
					failedPolicies.put(policyNo,"Policy number is wrong Policy Number");
					//System.exit(1);
				} else {
					System.out.println("PAS service failed");
					//System.exit(1);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (PolicySummary p1 : polsumlist) {
			System.out.println("************* Policy summary --" + gson.toJson(p1));
		}
		for (Orders o1 : orderslist) {
			System.out.println("************* Orders are --" + gson.toJson(o1));
		}
		// ord.setOrders(orderslist); will add the orderslist after discarding
		// the orders that are already processed
		polsums.setBatchOrders(polsumlist);
		System.out.println("policysummaries details are " + gson.toJson(polsums));
		String url = properties.getProperty("connectedhomes_addpolicy");
		HashMap<String, String> esResponse = outboundCalls(url, "post", polsums, "basic");
		System.out.println("addpoliy status is" +esResponse.get("status")+"addpoliy body is " +esResponse.get("body"));
		CHBatchResponse chBatchResponse = gson.fromJson(esResponse.get("body"), CHBatchResponse.class);
		int statusValue = Integer.parseInt(esResponse.get("status"));
		if (statusValue == 200) {
			// checking to see if connected homes app response had and policy
			// response as 400 code if so then that means this policy was
			// already processed
			for (CHResponse chresp : chBatchResponse.getPolicyResponses()) {
				if (chresp.getResponseMessage().equalsIgnoreCase("a document for this policy number has already been created")) {
					for (Iterator<Orders> it= orderslist.iterator(); it.hasNext(); ){
						Orders ords =it.next();
						if (ords.getORDER_NUMBER().split("_")[1].equalsIgnoreCase(chresp.getPolicyNumber())) {
							orderslist.remove(ords);
						}
					}
				}
			}
			ord.setOrders(orderslist);// adding the orderslist to the Order
										// Class
			System.out.println("Order details are " + ord.toString());
			// call to nest bulk order

			System.out.println("before making outbound call");
			HashMap<String, String> orderInitialResponse = outboundCalls(
					"/v1/bulk/csaa_http/orders/"+batchId, "post", ord, "digest"); /// v1/bulk/csaa_http/orders/+batchId
			System.out.println("orderInitialResponse status is " + orderInitialResponse.get("status")
					+ "orderInitialResponse body is " + orderInitialResponse.get("body"));
			int nestStatusValue = Integer.parseInt(orderInitialResponse.get("status"));
			// preparing the responses for connected homes api if the nest order
			// fails
			
			url = properties.getProperty("connectedhomes_batchupdate");
			if (nestStatusValue == 400) {
				NestResponses nestBody = gson.fromJson(orderInitialResponse.get("body"), NestResponses.class);
				for (NestResponse nestresp : nestBody.getNestResponses()) {
					if(!nestresp.getVALIDATION_ERRORS().equals("")){
						Response resp = new Response();
						resp.setOrder_number(nestresp.getORDER_NUMBER());
						resp.setOrderStatus("failed");
						resplist.add(resp);
						failedPolicies.put(nestresp.getORDER_NUMBER().split("_")[1],"Policy number is wrong Policy Number");
					}
				}
				resps.setBatchNestResponse(resplist);
				resps.setBatchStatus("invalid");
				resps.setBatch_id(batchId);
				if(!failedPolicies.isEmpty()){
					new SendEmail().composeEmail("Failed Policies",failedPolicies);
				}
				HashMap<String, String> failedResponse = outboundCalls(url, "post", resps, "basic");
				if (Integer.parseInt(failedResponse.get("status")) == 200) {
					System.out.println(
							"Connected Homes Elastic search is updated with the batch status for all the orders as failed for batchId"
									+ batchId);
				} else {
					System.out.println(
							"Failed to update Connected Homes Elastic search with the batch status/order status for batchId"
									+ batchId);
				}
			}
			else {
				System.out.println("posted to nest");
				// Move only the processed files to 'order_placed' directory

				for (File file : policyFilesDirectory.listFiles()) {
					if (filesprocessed.contains(file.getName())) {
						try {
							Files.move(Paths.get(file.getAbsolutePath()),
									Paths.get(file.getParent() + "\\order_placed\\" + file.getName() + ts),
									REPLACE_EXISTING);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
			
		} else {
			System.out.println(">> Return code is " + (esResponse.get("status")));
		}
	}

	public HashMap<String, String> outboundCalls(String uri, String method, Object obj, String type) {
		int nestStatusValue = 500, j = 0;
		HashMap<String, String> responseUri = new HashMap<>();
		while (nestStatusValue == 500 && j < 5) {
			try {
				if (type.equalsIgnoreCase("digest")) {
					responseUri = new RestClient().digestCall(uri, method, obj);
				} else {
					if (method == "post") {
						responseUri = new RestClient().post(uri, gson.toJson(obj));
					} else {
						responseUri = new RestClient().get(uri);
					}
				}
				nestStatusValue = Integer.parseInt(responseUri.get("status"));
				j++;
				Thread.sleep(60000); // 1000 milliseconds is one second.
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		System.out.println("url is " + uri);
		return responseUri;
	}

}
