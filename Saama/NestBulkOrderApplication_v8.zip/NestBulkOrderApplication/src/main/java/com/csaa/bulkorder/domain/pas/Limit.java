
package com.csaa.bulkorder.domain.pas;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Generated("org.jsonschema2pojo")
public class Limit {

    @SerializedName("individualLimitAmount")
    @Expose
    private String individualLimitAmount;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Limit() {
    }

    /**
     * 
     * @param individualLimitAmount
     */
    public Limit(String individualLimitAmount) {
        this.individualLimitAmount = individualLimitAmount;
    }

    /**
     * 
     * @return
     *     The individualLimitAmount
     */
    public String getIndividualLimitAmount() {
        return individualLimitAmount;
    }

    /**
     * 
     * @param individualLimitAmount
     *     The individualLimitAmount
     */
    public void setIndividualLimitAmount(String individualLimitAmount) {
        this.individualLimitAmount = individualLimitAmount;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(individualLimitAmount).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Limit) == false) {
            return false;
        }
        Limit rhs = ((Limit) other);
        return new EqualsBuilder().append(individualLimitAmount, rhs.individualLimitAmount).isEquals();
    }

}
