
package com.csaa.bulkorder.domain.pas;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class RetrievePolicyDetailResponse {
    private PropertyPolicySummary propertyPolicySummary;
    private Dwelling dwelling;
	public RetrievePolicyDetailResponse() {
		/*super();
		this.propertyPolicySummary = propertyPolicySummary;
		this.dwelling = dwelling;*/
	}
	public PropertyPolicySummary getPropertyPolicySummary() {
		return propertyPolicySummary;
	}
	public void setPropertyPolicySummary(PropertyPolicySummary propertyPolicySummary) {
		this.propertyPolicySummary = propertyPolicySummary;
	}
	public Dwelling getDwelling() {
		return dwelling;
	}
	public void setDwelling(Dwelling dwelling) {
		this.dwelling = dwelling;
	}
	 @Override
	    public int hashCode() {
	        return new HashCodeBuilder().append(propertyPolicySummary).append(dwelling).toHashCode();
	    }

	    @Override
	    public boolean equals(Object other) {
	        if (other == this) {
	            return true;
	        }
	        if ((other instanceof RetrievePolicyDetailResponse) == false) {
	            return false;
	        }
	        RetrievePolicyDetailResponse rhs = ((RetrievePolicyDetailResponse) other);
	        return new EqualsBuilder().append(propertyPolicySummary, rhs.propertyPolicySummary).append(dwelling, rhs.dwelling).isEquals();
	    }
}
