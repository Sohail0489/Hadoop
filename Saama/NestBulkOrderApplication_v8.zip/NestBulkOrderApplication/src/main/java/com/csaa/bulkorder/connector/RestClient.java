package com.csaa.bulkorder.connector;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.auth.DigestScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.util.EntityUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.csaa.bulkorder.property.GetPropertyValues;
import com.google.gson.Gson;

@SuppressWarnings("deprecation")
public class RestClient {

	// private String server =
	// "http://localhost:8080/BulkOrderService/webapi/myresource/getjson";
	private RestTemplate rest;
	private HttpHeaders headers;
	private HttpStatus status;
	Gson gson = new Gson();
	GetPropertyValues g = new GetPropertyValues();
	Properties properties = null;

	public RestClient() {
		this.rest = new RestTemplate();
		this.headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("Accept", "*/*");
	}

	public HashMap<String, String> get(String uri) {
		HashMap<String, String> returnValue = new HashMap<>();
		HttpEntity<String> requestEntity = new HttpEntity<String>("", headers);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.GET, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		returnValue.put("status", Integer.toString(responseEntity.getStatusCodeValue()));
		returnValue.put("body", responseEntity.getBody());
		// return
		// responseEntity.getStatusCodeValue()+"@"+responseEntity.getBody();
		return returnValue;
	}

	public HashMap<String, String> post(String uri, String json) {
		HashMap<String, String> returnValue = new HashMap<>();
		// System.out.println(">>>Inside Rest Post" + json + " -- " + uri);
		HttpEntity<String> requestEntity = new HttpEntity<String>(json, headers);
		// System.out.println(">>>After setting HTTPEntity Rest Post -- " +
		// requestEntity);
		ResponseEntity<String> responseEntity = rest.exchange(uri, HttpMethod.POST, requestEntity, String.class);
		// System.out.println(">>>After Rest Post-- " + responseEntity);
		this.setStatus(responseEntity.getStatusCode());
		returnValue.put("status", Integer.toString(responseEntity.getStatusCodeValue()));
		returnValue.put("body", responseEntity.getBody());
		// return responseEntity.getStatusCodeValue() + "@" +
		// responseEntity.getBody();
		return returnValue;
	}

	@SuppressWarnings("resource")
	@RequestMapping(value = "/nestTest", method = RequestMethod.GET)
	public HashMap<String, String> digestCall(String url, String method, Object obj) throws IOException {
		HashMap<String, String> returnValue = new HashMap<>();
		// https://integration.store.goldtest.nestlabs.com
		HttpHost targetHost = new HttpHost("integration.store.goldtest.nestlabs.com", 443, "https");
		HttpGet httpget = null;
		HttpPost httppost = null;
		HttpResponse response = null;
		try {
			properties = g.getPropValues();
			// System.out.println(properties.getProperty("Input_Directory"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DefaultHttpClient httpclient = new DefaultHttpClient();
		try {
			httpclient.getCredentialsProvider().setCredentials(new AuthScope(targetHost), // targetHost.getHostName(),
																							// targetHost.getPort()),
					new UsernamePasswordCredentials(properties.getProperty("user_name"),
							properties.getProperty("password")));

			// Create AuthCache instance
			AuthCache authCache = new BasicAuthCache();
			// Generate DIGEST scheme object, initialize it and add it to the
			// local
			// auth cache
			DigestScheme digestAuth = new DigestScheme();
			// Suppose we already know the realm name
			digestAuth.overrideParamter("realm", properties.getProperty("realm"));
			digestAuth.overrideParamter("qop", properties.getProperty("qop"));
			// Suppose we already know the expected nonce value
			// digestAuth.overrideParamter("nonce",
			// "MTQ2NzE1NjQ1MzUyOTo0NDg3YzRjMmNmZTljNDk3ZTE4ODlmZjY3OTJhNjY2OA==");
			authCache.put(targetHost, digestAuth);

			// Add AuthCache to the execution context
			BasicHttpContext localcontext = new BasicHttpContext();
			localcontext.setAttribute(ClientContext.AUTH_CACHE, authCache);
			if (method.equalsIgnoreCase("get")) {
				System.out.println("url is " + url);
				httpget = new HttpGet(url);// "/v1/bulk/csaa_http"
				response = httpclient.execute(targetHost, httpget, localcontext);

			} else {

				httppost = new HttpPost(url);
                                org.apache.http.entity.StringEntity params = new org.apache.http.entity.StringEntity("{ \"orders\":[  {    \"FIRST_NAME\":\"ADAM\",    \"LAST_NAME\":\"TEST\",    \"ADDRESS1\":\"2120 EL PASEO ST\",    \"ADDRESS2\":2802,    \"CITY\":\"HOUSTON\",    \"STATE\":\"TX\",    \"POSTAL_CODE\":\"77054-3230\",    \"COUNTRY\":\"US\",    \"EMAIL\":\"DONOTEMAIL_ff_mock@NESTLABS.COM\",    \"PHONE\":7132944883,    \"LANGUAGE_PREFERENCE\":\"EN\",    \"ORDER_NUMBER\":\"PO_35703894_1391540399728\",    \"ORDER_DATE\":\"10/24/2012\",    \"SKU\":\"T3007ES\",    \"QUANTITY\":\"1\"  }   ] }");
				//org.apache.http.entity.StringEntity params = new org.apache.http.entity.StringEntity(gson.toJson(obj));// "{
																													// }"
				httppost.addHeader("content-type", "application/json");
				httppost.setEntity(params);
				response = httpclient.execute(targetHost, httppost, localcontext);
			}
			// System.out.println("executing request: " +
			// httpget.getRequestLine());
			System.out.println("to target: " + targetHost);

			for (int i = 0; i < 3; i++) {
				org.apache.http.HttpEntity entity = response.getEntity();
				System.out.println(response.getStatusLine());
				if (entity != null) {
					System.out.println("Response content length: " + entity.getContentLength());
				}
				EntityUtils.consume(entity);
				returnValue.put("status", Integer.toString(response.getStatusLine().getStatusCode()));
				returnValue.put("body", response.getEntity().getContent().toString());

			}

		} finally {
			// When HttpClient instance is no longer needed,
			// shut down the connection manager to ensure
			// immediate deallocation of all system resources
			httpclient.getConnectionManager().shutdown();
		}
		return returnValue;
	}

	/*
	 * public void put(String uri, String json) { HttpEntity<String>
	 * requestEntity = new HttpEntity<String>(json, headers);
	 * ResponseEntity<String> responseEntity = rest.exchange(uri,
	 * HttpMethod.PUT, requestEntity, null);
	 * this.setStatus(responseEntity.getStatusCode()); }
	 * 
	 * public void delete(String uri) { HttpEntity<String> requestEntity = new
	 * HttpEntity<String>("", headers); ResponseEntity<String> responseEntity =
	 * rest.exchange(uri, HttpMethod.DELETE, requestEntity, null);
	 * this.setStatus(responseEntity.getStatusCode()); }
	 */
	/*
	 * public static void main(String[] args) { RestClient rs = new
	 * RestClient(); //String response = rs.post(
	 * "http://n01scl103.tent.trt.csaa.pri:8443/connectedhome/addPolicy",
	 * "{\"batchOrders\":[{\"agreementNumber\":\"11289907\",\"productCode\":\"HO3\",\"riskState\":\"NJ\",\"status\":\"CANCELLED\",\"nestBatchID\":\"Batch_2016.06.24.16.16.00\",\"nestBatchStatus\":\"initiated\",\"namedInsuredSummary\":[{\"firstName\":\"david\",\"lastName\":\"dias\"}],\"dwelling\":{\"cityName\":\"BARRINGTON\",\"zipCode\":\"08007-1711\",\"streetAddressLine\":\"2403 REAMER DR\",\"isoCountryCode\":\"US\",\"isoRegionCode\":\"NJ\",\"devices\":[{\"orderID\":\"Order_11289907_1466810163842\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_05239808_1466810164063\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_08239844_1466810164110\",\"orderStatus\":\"processing\"}]}},{\"agreementNumber\":\"05239808\",\"productCode\":\"HO4\",\"riskState\":\"PA\",\"status\":\"CANCELLED\",\"nestBatchID\":\"Batch_2016.06.24.16.16.00\",\"nestBatchStatus\":\"initiated\",\"namedInsuredSummary\":[{\"firstName\":\"heather\",\"lastName\":\"miller\"}],\"dwelling\":{\"cityName\":\"BARRINGTON\",\"zipCode\":\"08007-1711\",\"streetAddressLine\":\"2403 REAMER DR\",\"isoCountryCode\":\"US\",\"isoRegionCode\":\"NJ\",\"devices\":[{\"orderID\":\"Order_11289907_1466810163842\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_05239808_1466810164063\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_08239844_1466810164110\",\"orderStatus\":\"processing\"}]}},{\"agreementNumber\":\"08239844\",\"productCode\":\"HO4\",\"riskState\":\"NJ\",\"status\":\"CANCELLED\",\"nestBatchID\":\"Batch_2016.06.24.16.16.00\",\"nestBatchStatus\":\"initiated\",\"namedInsuredSummary\":[{\"firstName\":\"rocco\",\"lastName\":\"ambrico\"}],\"dwelling\":{\"cityName\":\"BARRINGTON\",\"zipCode\":\"08007-1711\",\"streetAddressLine\":\"2403 REAMER DR\",\"isoCountryCode\":\"US\",\"isoRegionCode\":\"NJ\",\"devices\":[{\"orderID\":\"Order_11289907_1466810163842\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_05239808_1466810164063\",\"orderStatus\":\"processing\"},{\"orderID\":\"Order_08239844_1466810164110\",\"orderStatus\":\"processing\"}]}}]}"
	 * ); //System.out.println(">> response from the call " + response); }
	 */

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
}
