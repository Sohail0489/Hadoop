package com.csaa.bulkorder.property;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.csaa.bulkorder.main.App;

public class GetPropertyValues {
	InputStream inputStream;

	public Properties getPropValues() throws IOException {
		Properties properties = new Properties();
		try {
			File jarPath = new File(App.class.getProtectionDomain().getCodeSource().getLocation().getPath());
			String propertiesPath = jarPath.getParentFile().getAbsolutePath();
			System.out.println("path is "+propertiesPath);
			properties.load(new FileInputStream(propertiesPath + "/application.properties"));
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return properties;
	}
}
