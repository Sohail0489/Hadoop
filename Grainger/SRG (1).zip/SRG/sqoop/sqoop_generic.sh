#Script to extract Tab From Traditional DBs and load to Hadoop and create hive table on top of Dataset
#Create by Sohail_Mohammed@grainger.com
#Date 10-05-2015

usage() {
cat <<EOF
  Extract Usage:
        -I - Ip address and jdbc connection of DB
        -D - Driver name of DB
        -u - Username of DB
        -p - Password of DB
        -d - Database
        -t - Tab Name
        -s - Split Column
        -m - Mode(lastmodified/append) enter "lastmodified" for tables having batchTS column(recommended for fact tables) or "append" for table having unique interger column(Recommended for dimension tables)
	-c - Checkcolumn value must be either batchtimestamp column name(if chosen mode as lastmodified) or UNIQUE integer column name(if chosen mode as append)
	-k - Primary key (please provide a uniquely column incase of -m lastmodified)
EOF
}

while getopts "I:D:u:p:d:t:s:m:c:k:" OPTION
do
    case $OPTION in
        I) DBIP=$OPTARG;;
        D) DBDriver=$OPTARG;;
        u) DBUserName=$OPTARG;;
        p) DBPassword=$OPTARG;;
        d) DataBase=$OPTARG;;
        t) Tab=$OPTARG;;
        s) Split=$OPTARG;;
        m) Mode=$OPTARG;;
	c) CheckColumn=$OPTARG;;
	k) Pkey=$OPTARG;;

    esac
done
. /hadoop/grainger/apps/hydra/scripts/SRG/sqoop/parameter.properties
File=$(echo "$Tab" | tr '[:upper:]' '[:lower:]')
echo "In sqoop_generic IP=${DBIP} Driver=${DBDriver} UsrNam=${DBUserName} PassWord=${DBPassword} DB=${DataBase} Table=${Tab} Split=${Split} Mode=${Mode} Check-column=${CheckColumn} and primary-key=${Pkey}, hivewarehouse:${Hive_warehouse}, hive tabel:${Schema_Import}.${Tab}, FILE =${File}" 

if [[  -z ${DBIP} ||  -z ${DBDriver} || -z ${DBUserName} || -z ${DBPassword} || -z ${DataBase} || -z ${Tab} || -z ${Split} || -z ${Mode} || -z ${CheckColumn} ]]
then echo "Options -u -p -d  -t -s -m -c -k can not be empty"
     echo "In sqoop_Generic IP= ${IP}/DRIVER=${Driver}/ USERNAME=${UserName}/ PASSWORD=${Password}/ DB=${DB}/ TABLE=${Tab}/ SPLIT=${Split} MODE=${Mode} Check-column=${CheckColumn} and primary-key=${Pkey}"
	 usage
     exit 1
fi

if [[ "${Mode}" = lastmodified && -z ${Pkey} ]];then
	echo "incase of -m is lastmodified then -k cant be empty, please provide a unique key"
	usage
	exit 1
fi

#incase somebody deleted temp DB
hive -e "CREATE DATABASE IF NOT EXISTS ${Schema_Import};CREATE DATABASE IF NOT EXISTS ${Schema};"
echo "DataBase creation done"

#this method extracts data both for lastmodified and append	
Extraction(){
if [[ "${Mode}" = lastmodified ]];then
	echo "Extraction last modified starts"
sqoop import \
--connect ${DBIP}/${DataBase} \
--driver ${DBDriver} \
--username ${DBUserName} \
--password ${DBPassword} \
-query "select * from ${Tab} where ${CheckColumn}>${lastvalue} AND \$CONDITIONS " \
--split-by ${Split} \
--merge-key ${Pkey} \
--compress \
--fields-terminated-by \| \
--incremental ${Mode} \
--check-column ${CheckColumn} \
--target-dir "${Hive_warehouse}/${File}" \
--hive-import \
--hive-table ${Schema_Import}.${Tab}

else
# in the current sqoop version --hive import flag is not supported with --incremental append flag, so seperating 1st time extract
	if [[ lastvalue -eq 0 ]];then
		echo "Extraction append starts first time"
	sqoop import \
	--connect ${DBIP}/${DataBase} \
	--driver ${DBDriver} \
	--username ${DBUserName} \
	--password ${DBPassword} \
	--table ${Tab} \
	--split-by ${Split} \
	--compress \
	--fields-terminated-by \| \
	--hive-import \
	--hive-table ${Schema_Import}.${Tab} \
	--target-dir "${Hive_warehouse}/${File}"

	else
		echo "Extraction append starts"
	sqoop import \
	--connect ${DBIP}/${DataBase} \
	--driver ${DBDriver} \
	--username ${DBUserName} \
	--password ${DBPassword} \
	-query "select * from ${Tab} where ${CheckColumn}>${lastvalue} AND \$CONDITIONS " \
	--split-by ${Split} \
	--compress \
	--fields-terminated-by \| \
	--incremental ${Mode} \
	--check-column ${CheckColumn} \
	--target-dir "${Hive_warehouse}/${File}" 
	fi

fi
}

#this method creates orc table out of default hive table
HiveOrcCreation(){
echo "****************************************************" 
echo "Hive Orc Table creation starts"	
hive -e "Drop table ${Schema}.${Tab};
    create table ${Schema}.${Tab} stored as ORC as select * from ${Schema_Import}.${Tab}"
    if [[ $? -ne 0 ]];then
		echo "Error...failed HIVE script for table ${Tab}"
		exit 1
    fi
	rm -f ${Script}/${Tab}*
	rm -f ${Script}/${Tab}.java
	echo "****************************************************"
	echo "hive table  ${Schema}.${Tab} is created"
}

## this method checks the record count between sqoop extraction and orc hive table
RecordCountCheck(){
echo "****************************************************"
echo "Record count starts"
td_count=`grep -w "Map input records"  ${LOGFILE}/${Tab}_${Date}|head -n 1|cut -d"=" -f2`
	if [[ td_count -ne 0 ]];then
		echo "${Tab} count is ${td_count}, so starting HiveOrcCreation method"
		HiveOrcCreation
		if [[ $? -ne 0 ]];then
			echo "Error...failed HiveOrcCreation method for table ${Tab}"
    			exit 1
		fi
	echo "Hive record count starts"	
       	hive_count=`hive -e "select count(*) from ${Schema}.${Tab} where ${CheckColumn}>$lastvalue"`
	else
		echo "sqoop fetched 0 records for ${Tab}"
		hive_count=0
	fi
echo "****************************************************"
}

# script starts from here
 
if hadoop fs -test -d "${Hive_warehouse}/${File}"
then
	echo "Table was extracted before, so picking the last value"
	lastvalue=`hive -e "select max(${CheckColumn}) from ${Schema_Import}.${Tab}"`
	if [[ "${Mode}" = lastmodified ]]
	then
		lastvalue=`echo $lastvalue|cut -d " " -f1,2`
		lastvalue="'${lastvalue}'"
	else
		lastvalue=`echo $lastvalue|cut -d " " -f1`
	fi
	
else
	echo "${Tab} importing for the first time"
	if [[ "${Mode}" = lastmodified ]]
	then
		lastvalue="'0001-01-01 00:01:01.0'"
	else
		lastvalue=0
	fi
fi

echo "MODE = ${Mode}  LAST VALUE = ${lastvalue}, calling the extraction method"
Extraction

echo "starting record count method"
RecordCountCheck
echo "Ending record count method"

echo "${Tab}-- record count of RDBMS is ${td_count}, and hive is ${hive_count}."

if [[ "${hive_count}"="${td_count}" ]];then
	echo "****************************************************"
	echo " sqoop script to extract ${Tab} ends on  `date +%m-%d-%Y' '%r`"
else
	echo "record count did not match"
#	echo "${Tab}-- Record count of teradata $td_count did not match with that of hive $hive_count"| mail -s "Sqoop Validation Failed" Sohail.Mohammed@grainger.com,Peter.Brousil@grainger.com
	exit 1
fi