PARAMETER.PROPERTIES:
	This properties file contains all environmental variables used through out the SRG scripts


TABLE.PROPERTIES:
	This properties file contains all the tables that are to be extracted daily and the format as follows
Source Name|DataBase Name|Table Name|Split-by column(an Integer column)|mode of extraction(lastmodified or append)|check-column|primary key(incase of lastmodified provide unique column else leave blank)


SQOOP_GENERIC.SH:
	This script is used to extract all the tables present in table properties file and it also creates the hive table on top of the extracted file. If the able is already there then it updates the table with newly extracted file.
If it does not find data from the source for the table it does not create any table


SQOOP_WRAPPER.SH:
	This script is the main script for data extraction and it calls the sqoop_generic file and logs the entire process for each table in the logging folder defined in the parameter file
