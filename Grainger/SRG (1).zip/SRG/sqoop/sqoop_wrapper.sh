#!/bin/bash
. /hadoop/grainger/apps/hydra/scripts/SRG/sqoop/parameter.properties 
while read line 
do
Source=`echo ${line}|cut -d'|' -f1`
DB=`echo ${line}|cut -d'|' -f2`
Tab=`echo ${line}|cut -d'|' -f3`
Split=`echo ${line}|cut -d'|' -f4`
Mode=`echo ${line}|cut -d'|' -f5`
CheckColumn=`echo ${line}|cut -d'|' -f6`
Pkey=`echo ${line}|cut -d'|' -f7`

eval IP='$'${Source}_IP
eval Driver='$'${Source}_Driver
eval UserName='$'${Source}_Usr
eval Password='$'${Source}_Pass


echo "full extract for ${Tab}" >${LOGFILE}/${Tab}_${Date}
echo "In sqoop_wrapper IP= ${IP}/DRIVER=${Driver}/ USERNAME=${UserName}/ PASSWORD=${Password}/ DB=${DB}/ TABLE=${Tab}/ SPLIT=${Split} MODE=${Mode} Check-column=${CheckColumn} Primary-Key=${Pkey}" > ${LOGFILE}/${Tab}_${Date}
${Script}/sqoop_generic.sh \
-I ${IP} \
-D ${Driver} \
-u ${UserName} \
-p ${Password} \
-d ${DB} \
-t ${Tab} \
-s ${Split} \
-m ${Mode} \
-c ${CheckColumn} \
-k ${Pkey} >${LOGFILE}/${Tab}_${Date} 2>&1

done < $Table;